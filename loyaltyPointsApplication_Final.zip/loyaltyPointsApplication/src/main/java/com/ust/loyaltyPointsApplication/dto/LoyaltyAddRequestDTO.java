package com.ust.loyaltyPointsApplication.dto;

import lombok.*;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LoyaltyAddRequestDTO {
    private Long userId;
    private String type;
    private String sourceName;
    private double billAmount;
}
