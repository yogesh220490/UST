package com.ust.loyaltyPointsApplication.strategy;

import com.ust.loyaltyPointsApplication.entity.HotelLegacy;
import com.ust.loyaltyPointsApplication.entity.LoyaltyPoint;
import com.ust.loyaltyPointsApplication.repository.HotelLegacyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class HotelLoyaltyMigration implements LoyaltyMigrationStrategy {

    @Autowired
    private HotelLegacyRepository hotelLegacyRepo;

    @Override
    public List<LoyaltyPoint> migrate(Long userId) {
        List<HotelLegacy> hotels = hotelLegacyRepo.findByUserId(userId);
        return hotels.stream()
                .map(h -> new LoyaltyPoint(null, userId, "HOTEL", h.getHotelName(), (int) (h.getBillAmount() * 0.1), h.getStayDate()))
                .collect(Collectors.toList());
    }

    @Override
    public String getType() {
        return "HOTEL";
    }
}
