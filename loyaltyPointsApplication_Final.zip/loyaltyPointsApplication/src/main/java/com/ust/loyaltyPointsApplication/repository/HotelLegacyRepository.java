package com.ust.loyaltyPointsApplication.repository;

import com.ust.loyaltyPointsApplication.entity.HotelLegacy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface HotelLegacyRepository extends JpaRepository<HotelLegacy, Long> {
    List<HotelLegacy> findByUserId(Long userId);
}
