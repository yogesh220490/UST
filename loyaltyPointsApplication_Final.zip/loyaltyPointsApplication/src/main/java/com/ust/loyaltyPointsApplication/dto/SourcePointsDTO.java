package com.ust.loyaltyPointsApplication.dto;

public class SourcePointsDTO {
    private String sourceName;
    private int points;
    public SourcePointsDTO(String sourceName, int points) {
        this.sourceName = sourceName;
        this.points = points;
    }
}
