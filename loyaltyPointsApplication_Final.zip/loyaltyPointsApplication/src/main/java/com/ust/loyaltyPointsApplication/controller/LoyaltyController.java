package com.ust.loyaltyPointsApplication.controller;

import com.ust.loyaltyPointsApplication.dto.LoyaltyAddRequestDTO;
import com.ust.loyaltyPointsApplication.dto.LoyaltyDetailsDTO;
import com.ust.loyaltyPointsApplication.dto.LoyaltySummaryDTO;
import com.ust.loyaltyPointsApplication.dto.LoyaltyUpdateDTO;
import com.ust.loyaltyPointsApplication.service.LoyaltyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/loyalty")
public class LoyaltyController {

    @Autowired
    private LoyaltyService loyaltyService;

    @PostMapping("/migrateLegacy/{userId}")
    public ResponseEntity<String> migrateLegacyData(@PathVariable Long userId) {
        loyaltyService.migrateLegacyDataToLoyaltyPoints(userId);
        return ResponseEntity.ok("Legacy data migrated successfully.");
    }

    @GetMapping("/summary/{userId}")
    public ResponseEntity<LoyaltySummaryDTO> getSummary(@PathVariable Long userId) {
        return ResponseEntity.ok(loyaltyService.getUserLoyaltySummary(userId));
    }

    @GetMapping("/details/{userId}")
    public ResponseEntity<LoyaltyDetailsDTO> getDetails(@PathVariable Long userId) {
        return ResponseEntity.ok(loyaltyService.getUserLoyaltyDetails(userId));
    }

    @PostMapping("/add")
    public ResponseEntity<String> addPoints(@RequestBody LoyaltyAddRequestDTO request) {
        loyaltyService.addLoyaltyPoints(request);
        return ResponseEntity.ok("Points added successfully.");
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updatePoints(@PathVariable Long id, @RequestBody LoyaltyUpdateDTO updateDTO) {
        loyaltyService.updatePoints(id, updateDTO.getPoints());
        return ResponseEntity.ok("Points updated.");
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deletePoints(@PathVariable Long id) {
        loyaltyService.deletePoints(id);
        return ResponseEntity.ok("Points deleted.");
    }
}

