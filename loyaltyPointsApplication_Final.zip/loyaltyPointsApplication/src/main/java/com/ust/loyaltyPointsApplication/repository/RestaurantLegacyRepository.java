package com.ust.loyaltyPointsApplication.repository;

import com.ust.loyaltyPointsApplication.entity.RestaurantLegacy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RestaurantLegacyRepository extends JpaRepository<RestaurantLegacy, Long> {
    List<RestaurantLegacy> findByUserId(Long userId);
}
