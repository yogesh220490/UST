package com.ust.loyaltyPointsApplication.service;


import com.ust.loyaltyPointsApplication.dto.LoyaltyAddRequestDTO;
import com.ust.loyaltyPointsApplication.dto.LoyaltyDetailsDTO;
import com.ust.loyaltyPointsApplication.dto.LoyaltySummaryDTO;
import com.ust.loyaltyPointsApplication.dto.SourcePointsDTO;
import com.ust.loyaltyPointsApplication.entity.LoyaltyPoint;
import com.ust.loyaltyPointsApplication.repository.*;
import com.ust.loyaltyPointsApplication.strategy.LoyaltyMigrationStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class LoyaltyService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private LoyaltyPointRepository loyaltyRepo;

    @Autowired
    private HotelLegacyRepository hotelLegacyRepo;

    @Autowired
    private CasinoLegacyRepository casinoLegacyRepo;

    @Autowired
    private RestaurantLegacyRepository restaurantLegacyRepo;

    private final Map<String, LoyaltyMigrationStrategy> strategyMap;

    @Autowired
    public LoyaltyService(List<LoyaltyMigrationStrategy> strategies) {
        this.strategyMap = new HashMap<>();
        for (LoyaltyMigrationStrategy strategy : strategies) {
            this.strategyMap.put(strategy.getType(), strategy);
        }
    }
    public void migrateLegacyDataToLoyaltyPoints(Long userId) {
        for (LoyaltyMigrationStrategy strategy : strategyMap.values()) {
            List<LoyaltyPoint> points = strategy.migrate(userId);
            loyaltyRepo.saveAll(points);
        }
    }
    public LoyaltySummaryDTO getUserLoyaltySummary(Long userId) {
        List<LoyaltyPoint> points = loyaltyRepo.findByUserId(userId);
        String userName = userRepository.findById(userId).orElseThrow().getName();

        int hotel = 0, casino = 0, restaurant = 0;

        for (LoyaltyPoint p : points) {
            switch (p.getType()) {
                case "HOTEL": hotel += p.getPoints(); break;
                case "CASINO": casino += p.getPoints(); break;
                case "RESTAURANT": restaurant += p.getPoints(); break;
            }
        }

        return new LoyaltySummaryDTO(userName, hotel, casino, restaurant);
    }

    public LoyaltyDetailsDTO getUserLoyaltyDetails(Long userId) {
        String userName = userRepository.findById(userId).orElseThrow().getName();
        List<LoyaltyPoint> points = loyaltyRepo.findByUserId(userId);

        Map<String, List<SourcePointsDTO>> map = new HashMap<>();
        map.put("HOTEL", new ArrayList<>());
        map.put("CASINO", new ArrayList<>());
        map.put("RESTAURANT", new ArrayList<>());

        for (LoyaltyPoint lp : points) {
            map.get(lp.getType()).add(new SourcePointsDTO(lp.getSourceName(), lp.getPoints()));
        }

        return new LoyaltyDetailsDTO(userName, map.get("HOTEL"), map.get("CASINO"), map.get("RESTAURANT"));
    }

    public void addLoyaltyPoints(LoyaltyAddRequestDTO dto) {
        int calculatedPoints = calculatePoints(dto.getType(), dto.getBillAmount());
        LoyaltyPoint lp = new LoyaltyPoint(null, dto.getUserId(), dto.getType(), dto.getSourceName(), calculatedPoints, LocalDate.now());
        loyaltyRepo.save(lp);
    }

    public void updatePoints(Long id, int newPoints) {
        LoyaltyPoint lp = loyaltyRepo.findById(id).orElseThrow();
        lp.setPoints(newPoints);
        loyaltyRepo.save(lp);
    }

    public void deletePoints(Long id) {
        loyaltyRepo.deleteById(id);
    }

    private int calculatePoints(String type, double billAmount) {
        switch (type.toUpperCase()) {
            case "HOTEL": return (int) (billAmount * 0.1);
            case "CASINO": return (int) (billAmount);
            case "RESTAURANT": return (int) (billAmount * 0.2);
            default: throw new IllegalArgumentException("Invalid type");
        }
    }
}
