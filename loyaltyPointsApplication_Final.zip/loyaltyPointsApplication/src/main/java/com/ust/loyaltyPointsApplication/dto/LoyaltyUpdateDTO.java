package com.ust.loyaltyPointsApplication.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class LoyaltyUpdateDTO {
    private int points;
}
