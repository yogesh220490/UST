package com.ust.loyaltyPointsApplication.repository;

import com.ust.loyaltyPointsApplication.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {}


