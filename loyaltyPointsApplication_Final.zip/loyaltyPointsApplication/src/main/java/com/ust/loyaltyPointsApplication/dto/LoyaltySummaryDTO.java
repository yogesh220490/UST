package com.ust.loyaltyPointsApplication.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class LoyaltySummaryDTO {
    private String userName;
    private int hotelPoints, casinoPoints, restaurantPoints, totalPoints;

    public LoyaltySummaryDTO(String userName, int hotel, int casino, int restaurant) {
        this.userName = userName;
        this.hotelPoints = hotel;
        this.casinoPoints = casino;
        this.restaurantPoints = restaurant;
        this.totalPoints = hotel + casino + restaurant;
    }
}
