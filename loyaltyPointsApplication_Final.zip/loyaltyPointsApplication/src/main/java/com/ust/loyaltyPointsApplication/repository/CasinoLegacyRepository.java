package com.ust.loyaltyPointsApplication.repository;

import com.ust.loyaltyPointsApplication.entity.CasinoLegacy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CasinoLegacyRepository extends JpaRepository<CasinoLegacy, Long> {
    List<CasinoLegacy> findByUserId(Long userId);
}
