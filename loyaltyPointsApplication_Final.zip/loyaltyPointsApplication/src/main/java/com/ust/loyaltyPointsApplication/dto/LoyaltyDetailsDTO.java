package com.ust.loyaltyPointsApplication.dto;

import lombok.*;

import java.util.List;

@Data
@Getter
@Setter
@NoArgsConstructor
public class LoyaltyDetailsDTO {
    private String userName;
    private List<SourcePointsDTO> hotelDetails;
    private List<SourcePointsDTO> casinoDetails;
    private List<SourcePointsDTO> restaurantDetails;

    public LoyaltyDetailsDTO(String userName, List<SourcePointsDTO> hotel, List<SourcePointsDTO> casino, List<SourcePointsDTO> restaurant) {
        this.userName = userName;
        this.hotelDetails = hotel;
        this.casinoDetails = casino;
        this.restaurantDetails = restaurant;
    }
}
