package com.ust.loyaltyPointsApplication.strategy;

import com.ust.loyaltyPointsApplication.entity.LoyaltyPoint;
import com.ust.loyaltyPointsApplication.repository.CasinoLegacyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class CasinoLoyaltyMigration implements LoyaltyMigrationStrategy {

    @Autowired
    private CasinoLegacyRepository casinoLegacyRepo;

    @Override
    public List<LoyaltyPoint> migrate(Long userId) {
        return casinoLegacyRepo.findByUserId(userId).stream()
                .map(c -> new LoyaltyPoint(null, userId, "CASINO", c.getCasinoName(), (int) c.getAmountSpent(), c.getVisitDate()))
                .collect(Collectors.toList());
    }

    @Override
    public String getType() {
        return "CASINO";
    }
}
