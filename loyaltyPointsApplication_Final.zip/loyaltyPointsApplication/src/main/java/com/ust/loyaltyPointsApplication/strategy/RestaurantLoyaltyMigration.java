package com.ust.loyaltyPointsApplication.strategy;

import com.ust.loyaltyPointsApplication.entity.LoyaltyPoint;
import com.ust.loyaltyPointsApplication.repository.RestaurantLegacyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class RestaurantLoyaltyMigration implements LoyaltyMigrationStrategy {

    @Autowired
    private RestaurantLegacyRepository restaurantLegacyRepo;

    @Override
    public List<LoyaltyPoint> migrate(Long userId) {
        return restaurantLegacyRepo.findByUserId(userId).stream()
                .map(r -> new LoyaltyPoint(null, userId, "RESTAURANT", r.getRestaurantName(), (int) (r.getBillAmount() * 0.2), r.getDineDate()))
                .collect(Collectors.toList());
    }

    @Override
    public String getType() {
        return "RESTAURANT";
    }
}
