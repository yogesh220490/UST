package com.ust.loyaltyPointsApplication.strategy;

import com.ust.loyaltyPointsApplication.entity.LoyaltyPoint;

import java.util.List;

public interface LoyaltyMigrationStrategy {
    List<LoyaltyPoint> migrate(Long userId);
    String getType();  // To help with registration
}
