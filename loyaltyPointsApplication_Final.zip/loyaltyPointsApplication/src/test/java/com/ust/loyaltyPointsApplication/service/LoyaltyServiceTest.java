package com.ust.loyaltyPointsApplication.service;

import com.ust.loyaltyPointsApplication.dto.LoyaltyAddRequestDTO;
import com.ust.loyaltyPointsApplication.dto.LoyaltyDetailsDTO;
import com.ust.loyaltyPointsApplication.dto.LoyaltySummaryDTO;
import com.ust.loyaltyPointsApplication.entity.LoyaltyPoint;
import com.ust.loyaltyPointsApplication.entity.User;
import com.ust.loyaltyPointsApplication.repository.*;
import com.ust.loyaltyPointsApplication.strategy.LoyaltyMigrationStrategy;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
class LoyaltyServiceTest {

    @Mock private UserRepository userRepository;
    @Mock private LoyaltyPointRepository loyaltyRepo;
    @Mock private HotelLegacyRepository hotelLegacyRepo;
    @Mock private CasinoLegacyRepository casinoLegacyRepo;
    @Mock private RestaurantLegacyRepository restaurantLegacyRepo;

    @Mock private LoyaltyMigrationStrategy hotelStrategy;
    @Mock private LoyaltyMigrationStrategy casinoStrategy;

    private LoyaltyService loyaltyService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);

        when(hotelStrategy.getType()).thenReturn("HOTEL");
        when(casinoStrategy.getType()).thenReturn("CASINO");

        // Inject strategy list via constructor
        loyaltyService = new LoyaltyService(List.of(hotelStrategy, casinoStrategy));

        // Use reflection to set other private fields
        setPrivateField(loyaltyService, "userRepository", userRepository);
        setPrivateField(loyaltyService, "loyaltyRepo", loyaltyRepo);
        setPrivateField(loyaltyService, "hotelLegacyRepo", hotelLegacyRepo);
        setPrivateField(loyaltyService, "casinoLegacyRepo", casinoLegacyRepo);
        setPrivateField(loyaltyService, "restaurantLegacyRepo", restaurantLegacyRepo);
    }

    private void setPrivateField(Object target, String fieldName, Object value) {
        try {
            Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Exception e) {
            throw new RuntimeException("Failed to inject field: " + fieldName, e);
        }
    }

    @Test
    void testMigrateLegacyDataToLoyaltyPoints() {
        Long userId = 1L;
        List<LoyaltyPoint> hotelPoints = List.of(new LoyaltyPoint());
        List<LoyaltyPoint> casinoPoints = List.of(new LoyaltyPoint());

        when(hotelStrategy.migrate(userId)).thenReturn(hotelPoints);
        when(casinoStrategy.migrate(userId)).thenReturn(casinoPoints);

        loyaltyService.migrateLegacyDataToLoyaltyPoints(userId);

        verify(loyaltyRepo).saveAll(hotelPoints);
        verify(loyaltyRepo).saveAll(casinoPoints);
    }

    @Test
    void testGetUserLoyaltySummary() {
        Long userId = 1L;
        List<LoyaltyPoint> points = List.of(
                new LoyaltyPoint(1L, userId, "HOTEL", "Hotel A", 100, LocalDate.now()),
                new LoyaltyPoint(2L, userId, "CASINO", "Casino A", 200, LocalDate.now()),
                new LoyaltyPoint(3L, userId, "RESTAURANT", "Restaurant A", 50, LocalDate.now())
        );

        when(loyaltyRepo.findByUserId(userId)).thenReturn(points);
        when(userRepository.findById(userId)).thenReturn(Optional.of(new User(userId, "Alice")));

        LoyaltySummaryDTO result = loyaltyService.getUserLoyaltySummary(userId);

        assertEquals("Alice", result.getUserName());
        assertEquals(100, result.getHotelPoints());
        assertEquals(200, result.getCasinoPoints());
        assertEquals(50, result.getRestaurantPoints());
    }

    @Test
    void testGetUserLoyaltyDetails() {
        Long userId = 1L;
        List<LoyaltyPoint> points = List.of(
                new LoyaltyPoint(1L, userId, "HOTEL", "Hotel A", 100, LocalDate.now()),
                new LoyaltyPoint(2L, userId, "CASINO", "Casino A", 200, LocalDate.now())
        );

        when(loyaltyRepo.findByUserId(userId)).thenReturn(points);
        when(userRepository.findById(userId)).thenReturn(Optional.of(new User(userId, "Bob")));

        LoyaltyDetailsDTO result = loyaltyService.getUserLoyaltyDetails(userId);

        assertEquals("Bob", result.getUserName());
    }

    @Test
    void testAddLoyaltyPoints() {
        LoyaltyAddRequestDTO dto = new LoyaltyAddRequestDTO(1L, "HOTEL", "Hotel X", 1000.0);

        loyaltyService.addLoyaltyPoints(dto);

        ArgumentCaptor<LoyaltyPoint> captor = ArgumentCaptor.forClass(LoyaltyPoint.class);
        verify(loyaltyRepo).save(captor.capture());

        LoyaltyPoint saved = captor.getValue();
        assertEquals("HOTEL", saved.getType());
        assertEquals(100, saved.getPoints()); // 1000 * 0.1
    }

    @Test
    void testUpdatePoints() {
        LoyaltyPoint lp = new LoyaltyPoint(1L, 1L, "CASINO", "Casino Y", 200, LocalDate.now());
        when(loyaltyRepo.findById(1L)).thenReturn(Optional.of(lp));

        loyaltyService.updatePoints(1L, 300);

        assertEquals(300, lp.getPoints());
        verify(loyaltyRepo).save(lp);
    }

    @Test
    void testDeletePoints() {
        loyaltyService.deletePoints(1L);
        verify(loyaltyRepo).deleteById(1L);
    }
}
