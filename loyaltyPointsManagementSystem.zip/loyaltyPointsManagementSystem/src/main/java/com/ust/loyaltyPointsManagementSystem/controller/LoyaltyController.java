package com.ust.loyaltyPointsManagementSystem.controller;

import com.ust.loyaltyPointsManagementSystem.dto.LoyaltyAddRequestDTO;
import com.ust.loyaltyPointsManagementSystem.dto.LoyaltyDetailsDTO;
import com.ust.loyaltyPointsManagementSystem.dto.LoyaltySummaryDTO;
import com.ust.loyaltyPointsManagementSystem.dto.LoyaltyUpdateDTO;
import com.ust.loyaltyPointsManagementSystem.service.LoyaltyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/loyalty")
public class LoyaltyController {

    @Autowired
    private LoyaltyService loyaltyService;

    @GetMapping("/summary/{userId}")
    public ResponseEntity<LoyaltySummaryDTO> getSummary(@PathVariable Long userId) {
        return ResponseEntity.ok(loyaltyService.getUserLoyaltySummary(userId));
    }

    @GetMapping("/details/{userId}")
    public ResponseEntity<LoyaltyDetailsDTO> getDetails(@PathVariable Long userId) {
        return ResponseEntity.ok(loyaltyService.getUserLoyaltyDetails(userId));
    }

    @PostMapping("/add")
    public ResponseEntity<String> addPoints(@RequestBody LoyaltyAddRequestDTO request) {
        loyaltyService.addLoyaltyPoints(request);
        return ResponseEntity.ok("Points added successfully.");
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updatePoints(@PathVariable Long id, @RequestBody LoyaltyUpdateDTO updateDTO) {
        loyaltyService.updatePoints(id, updateDTO.getPoints());
        return ResponseEntity.ok("Points updated.");
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deletePoints(@PathVariable Long id) {
        loyaltyService.deletePoints(id);
        return ResponseEntity.ok("Points deleted.");
    }
}

