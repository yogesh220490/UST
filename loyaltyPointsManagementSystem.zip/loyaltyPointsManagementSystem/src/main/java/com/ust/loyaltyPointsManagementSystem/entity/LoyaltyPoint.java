package com.ust.loyaltyPointsManagementSystem.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import lombok.*;
import org.springframework.data.annotation.Id;

import java.time.LocalDate;

@Entity
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LoyaltyPoint {
    @Id
    @GeneratedValue
    private Long id;
    private Long userId;
    private String type; // HOTEL, CASINO, RESTAURANT
    private String sourceName;
    private int points;
    private
    LocalDate createdDate;
}
