package com.ust.loyaltyPointsManagementSystem.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;

@Entity
@Setter
@Getter
public class User {
    @Id
    @GeneratedValue
    private Long id;
    private String name;
}

