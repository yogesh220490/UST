package com.ust.loyaltyPointsManagementSystem.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Data
@Getter
@Setter
public class LoyaltyDetailsDTO {
    private String userName;
    private List<SourcePointsDTO> hotelDetails;
    private List<SourcePointsDTO> casinoDetails;
    private List<SourcePointsDTO> restaurantDetails;

    public LoyaltyDetailsDTO(String userName, List<SourcePointsDTO> hotel, List<SourcePointsDTO> casino, List<SourcePointsDTO> restaurant) {
        this.userName = userName;
        this.hotelDetails = hotel;
        this.casinoDetails = casino;
        this.restaurantDetails = restaurant;
    }
}
