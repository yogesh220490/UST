package com.ust.loyaltyPointsManagementSystem.service;


import com.ust.loyaltyPointsManagementSystem.dto.LoyaltyAddRequestDTO;
import com.ust.loyaltyPointsManagementSystem.dto.LoyaltyDetailsDTO;
import com.ust.loyaltyPointsManagementSystem.dto.LoyaltySummaryDTO;
import com.ust.loyaltyPointsManagementSystem.dto.SourcePointsDTO;
import com.ust.loyaltyPointsManagementSystem.entity.LoyaltyPoint;
import com.ust.loyaltyPointsManagementSystem.repository.LoyaltyPointRepository;
import com.ust.loyaltyPointsManagementSystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class LoyaltyService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private LoyaltyPointRepository loyaltyRepo;

    public LoyaltySummaryDTO getUserLoyaltySummary(Long userId) {
        List<LoyaltyPoint> points = loyaltyRepo.findByUserId(userId);
        String userName = userRepository.findById(userId).orElseThrow().getName();

        int hotel = 0, casino = 0, restaurant = 0;

        for (LoyaltyPoint p : points) {
            switch (p.getType()) {
                case "HOTEL": hotel += p.getPoints(); break;
                case "CASINO": casino += p.getPoints(); break;
                case "RESTAURANT": restaurant += p.getPoints(); break;
            }
        }

        return new LoyaltySummaryDTO(userName, hotel, casino, restaurant);
    }

    public LoyaltyDetailsDTO getUserLoyaltyDetails(Long userId) {
        String userName = userRepository.findById(userId).orElseThrow().getName();
        List<LoyaltyPoint> points = loyaltyRepo.findByUserId(userId);

        Map<String, List<SourcePointsDTO>> map = new HashMap<>();
        map.put("HOTEL", new ArrayList<>());
        map.put("CASINO", new ArrayList<>());
        map.put("RESTAURANT", new ArrayList<>());

        for (LoyaltyPoint lp : points) {
            map.get(lp.getType()).add(new SourcePointsDTO(lp.getSourceName(), lp.getPoints()));
        }

        return new LoyaltyDetailsDTO(userName, map.get("HOTEL"), map.get("CASINO"), map.get("RESTAURANT"));
    }

    public void addLoyaltyPoints(LoyaltyAddRequestDTO dto) {
        int calculatedPoints = calculatePoints(dto.getType(), dto.getBillAmount());
        LoyaltyPoint lp = new LoyaltyPoint(null, dto.getUserId(), dto.getType(), dto.getSourceName(), calculatedPoints, LocalDate.now());
        loyaltyRepo.save(lp);
    }

    public void updatePoints(Long id, int newPoints) {
        LoyaltyPoint lp = loyaltyRepo.findById(id).orElseThrow();
        lp.setPoints(newPoints);
        loyaltyRepo.save(lp);
    }

    public void deletePoints(Long id) {
        loyaltyRepo.deleteById(id);
    }

    private int calculatePoints(String type, double billAmount) {
        switch (type.toUpperCase()) {
            case "HOTEL": return (int) (billAmount * 0.1);
            case "CASINO": return (int) (billAmount);
            case "RESTAURANT": return (int) (billAmount * 0.2);
            default: throw new IllegalArgumentException("Invalid type");
        }
    }
}
