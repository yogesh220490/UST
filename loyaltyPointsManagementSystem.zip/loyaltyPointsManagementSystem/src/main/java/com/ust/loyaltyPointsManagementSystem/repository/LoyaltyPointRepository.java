package com.ust.loyaltyPointsManagementSystem.repository;

import com.ust.loyaltyPointsManagementSystem.entity.LoyaltyPoint;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LoyaltyPointRepository extends JpaRepository<LoyaltyPoint, Long> {
    List<LoyaltyPoint> findByUserId(Long userId);
}
