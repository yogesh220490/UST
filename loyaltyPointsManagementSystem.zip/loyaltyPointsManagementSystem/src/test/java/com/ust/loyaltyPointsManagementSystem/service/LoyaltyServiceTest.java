package com.ust.loyaltyPointsManagementSystem.service;

import com.ust.loyaltyPointsManagementSystem.dto.LoyaltyAddRequestDTO;
import com.ust.loyaltyPointsManagementSystem.dto.LoyaltyDetailsDTO;
import com.ust.loyaltyPointsManagementSystem.dto.LoyaltySummaryDTO;
import com.ust.loyaltyPointsManagementSystem.entity.LoyaltyPoint;
import com.ust.loyaltyPointsManagementSystem.entity.User;
import com.ust.loyaltyPointsManagementSystem.repository.LoyaltyPointRepository;
import com.ust.loyaltyPointsManagementSystem.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.springframework.test.util.AssertionErrors.assertEquals;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class LoyaltyServiceTest {

    @InjectMocks
    private LoyaltyService loyaltyService;

    @Mock
    private LoyaltyPointRepository loyaltyRepo;

    @Mock
    private UserRepository userRepo;

    private User testUser;
    private List<LoyaltyPoint> testPoints;

    @BeforeEach
    void setup() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setName("Yogesh");

        testPoints = Arrays.asList(
                new LoyaltyPoint(1L, 1L, "HOTEL", "Taj", 3000, LocalDate.now()),
                new LoyaltyPoint(2L, 1L, "HOTEL", "Marriott", 7000, LocalDate.now()),
                new LoyaltyPoint(3L, 1L, "CASINO", "Bellagio", 20000, LocalDate.now()),
                new LoyaltyPoint(4L, 1L, "RESTAURANT", "Olive", 2000, LocalDate.now())
        );
    }

    @Test
    void testGetUserLoyaltySummary() {
        Mockito.when(userRepo.findById(1L)).thenReturn(Optional.of(testUser));
        Mockito.when(loyaltyRepo.findByUserId(1L)).thenReturn(testPoints);

        LoyaltySummaryDTO result = loyaltyService.getUserLoyaltySummary(1L);

        assertEquals("Result","Yogesh", result.getUserName());
        assertEquals("Result",10000, result.getHotelPoints());
        assertEquals("Result",20000, result.getCasinoPoints());
        assertEquals("Result",2000, result.getRestaurantPoints());
        assertEquals("Result",32000, result.getTotalPoints());
    }

    @Test
    void testGetUserLoyaltyDetails() {
        Mockito.when(userRepo.findById(1L)).thenReturn(Optional.of(testUser));
        Mockito.when(loyaltyRepo.findByUserId(1L)).thenReturn(testPoints);

        LoyaltyDetailsDTO result = loyaltyService.getUserLoyaltyDetails(1L);

        assertEquals("Result","Yogesh", result.getUserName());
        assertEquals("Result",2, result.getHotelDetails().size());
        assertEquals("Result",1, result.getCasinoDetails().size());
        assertEquals("Result",1, result.getRestaurantDetails().size());
    }

    @Test
    void testAddLoyaltyPoints() {
        LoyaltyAddRequestDTO dto = new LoyaltyAddRequestDTO();
        dto.setUserId(1L);
        dto.setType("HOTEL");
        dto.setSourceName("Hyatt");
        dto.setBillAmount(5000);

        ArgumentCaptor<LoyaltyPoint> captor = ArgumentCaptor.forClass(LoyaltyPoint.class);

        loyaltyService.addLoyaltyPoints(dto);

        Mockito.verify(loyaltyRepo).save(captor.capture());

        LoyaltyPoint saved = captor.getValue();
        assertEquals("Result","HOTEL", saved.getType());
        assertEquals("Result","Hyatt", saved.getSourceName());
        assertEquals("Result","500", saved.getPoints()); // 10% of 5000
    }

    @Test
    void testUpdatePoints() {
        LoyaltyPoint lp = new LoyaltyPoint(1L, 1L, "HOTEL", "Taj", 3000, LocalDate.now());

        Mockito.when(loyaltyRepo.findById(1L)).thenReturn(Optional.of(lp));

        loyaltyService.updatePoints(1L, 8000);

        assertEquals("Result","8000", lp.getPoints());
        Mockito.verify(loyaltyRepo).save(lp);
    }

    @Test
    void testDeletePoints() {
        loyaltyService.deletePoints(1L);
        Mockito.verify(loyaltyRepo).deleteById(1L);
    }
}

